// Scenario: Login fails with incorrect password

describe('Login fails with incorrect password', () => 
{
    it('should remain on the login page and show "Username and password do not match any user in this service" error message', () => 
    {
      // Buka halaman Swag Labs
      cy.visit('https://www.saucedemo.com');
      cy.get('#user-name').type('standard_user');     // Contoh : standard_user
      cy.get('#password').type('wrong_password');     // PW : lalala (wrong password)
      cy.get('#login-button').click();
      cy.url().should('include', '/index.html'); 
      cy.get('.error-message-container')
        .should('be.visible')
        .and('contain', 'Username and password do not match any user in this service');
    });
  });
  