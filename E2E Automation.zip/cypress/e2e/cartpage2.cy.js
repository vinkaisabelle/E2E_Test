// 

describe('Checkout Overview Page - Complete Purchase', () => {
    it('should finish the purchase and show the Thank You page', () => {
      cy.visit('https://www.saucedemo.com/cart.html');
      cy.get('.btn_action').click();
      cy.get('.complete-header').should('contain', 'Thank you for your order');
      cy.get('.order_summary').should('be.visible'); 
      cy.get('.cart_item').should('have.length.greaterThan', 0);
      cy.get('.summary_total_label').should('contain', 'Total:');
    });
  });
  