// Scenario: Login fails with incorrect username

describe('Login - Incorrect Username', () => 
    {
    beforeEach(() => 
    {
      cy.visit('https://www.saucedemo.com/');
    });
  
    it('should show an error message when an incorrect username is entered', () => 
    {
      // Di sini kita klik tombol login
      cy.get('[data-test="login-button"]').click();
      cy.get('[data-test="username"]').type('standart_user'); // Masukkan username yang salah (typo)
      cy.get('[data-test="password"]').type('secret_sauce'); // Password yang benar
      cy.get('[data-test="login-button"]').click(); // Klik tombol login untuk submit form
  
      // Verifikasi bahwa pengguna tetap berada di halaman login
      cy.url().should('eq', 'https://www.saucedemo.com/');
  
      // Verifikasi error message yang muncul
      cy.contains('Username and password do not match any user in this service').should('be.visible');
    });
  });
  