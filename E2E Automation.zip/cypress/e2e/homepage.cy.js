// Scenario: In Homepage user clicks a product on the Swag Labs website

describe('Add Product to Cart', () => 
    {
    beforeEach(() => 
    {
      cy.visit('https://www.saucedemo.com/');
    });
  
    it('should add a product to the cart and update the cart icon', () => 
    {
      cy.get('[data-test="username"]').type('standard_user');  // masukkan username
      cy.get('[data-test="password"]').type('secret_sauce');  // masukkan password
      cy.get('[data-test="login-button"]').click();  // Klik tombol login
      
      // Klik produk pertama dalam daftar produk
      cy.get('.inventory_item').first().click();  
      // Klik tombol "Add to Cart"
      cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
      // Verifikasi bahwa produk telah ditambahkan ke dalam keranjang
      cy.get('.shopping_cart_badge').should('have.text', '1');  
      // Verifikasi bahwa ikon keranjang telah diperbarui
      cy.get('.shopping_cart_link').click(); 
      cy.url().should('include', '/cart.html'); // User akan diarahkan ke bagian keranjang (cart)
      cy.get('.cart_item').should('have.length', 1);  // Di sini posisinya hanya ada 1 item
    });
  });
  