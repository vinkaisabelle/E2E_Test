// Scenario: User clicks cancel on the checkout overview page and returns to the cart

describe('Checkout Overview - Cancel Flow', () => 
{
    beforeEach(() => 
    {
      cy.visit('https://www.saucedemo.com/');
      cy.get('[data-test="username"]').type('standard_user');
      cy.get('[data-test="password"]').type('secret_sauce'); 
      cy.get('[data-test="login-button"]').click();
      cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click(); 
      cy.get('[data-test="shopping_cart_container"]').click(); 
      cy.get('[data-test="checkout"]').click();
    });
  
    it('should show confirmation pop-up when clicking cancel on checkout overview page', () => 
    {
      cy.url().should('include', '/checkout-step-two');
      cy.get('[data-test="cancel"]').click();
      cy.get('.modal').should('be.visible');
      cy.contains('Do you want to cancel?').should('be.visible');
      cy.get('.btn_secondary').should('contain', 'No');
      cy.get('.btn_primary').should('contain', 'Yes');
    });
  
    it('should return to the cart if "Yes" is clicked in the cancel confirmation', () => 
    {
      cy.get('.btn_primary').click();
      cy.url().should('include', '/cart.html');
    });
  
    it('should stay on the checkout overview if "No" is clicked in the cancel confirmation', () => 
    {
      cy.get('.btn_secondary').click();
      cy.url().should('include', '/checkout-step-two');
    });
  });
  