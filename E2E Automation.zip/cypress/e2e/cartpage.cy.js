// Scenario: User enters invalid name and zip code and clicks continue

describe('Checkout Page - Invalid Name and Zip Code', () => 
{
    it('should display error messages for invalid name and zip code', () => 
    {
      cy.visit('https://www.saucedemo.com/cart.html'); 
      cy.get('.checkout_button').click();
      cy.get('input[name="name"]').type('.'); // input nama yang salah. contohnya (.)
      cy.get('input[name="zip"]').type('.'); // input zipcode yang salah. contohnya (.)
      cy.get('button[name="continue"]').click();
      cy.get('.error-message').should('contain', 'Please enter a valid name');
      cy.get('.error-message').should('contain', 'Please enter a valid zip code');
    });
  });
  