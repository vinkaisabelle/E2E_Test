// Scenario Login fails when username is not entered

describe('Login fails when username is not entered', () => 
{
    it('should remain on the login page and show "Username is required" error message', () => 
    {
      // Masuk ke halaman login
      cy.visit('https://www.saucedemo.com');
  
      // Pengguna tidak memasukkan username, tetapi tetap input password
      cy.get('#user-name').clear();
      cy.get('#password').type('secret_sauce');
      cy.get('#login-button').click();
      cy.url().should('include', '/index.html'); 
  
      // Harapannya yaitu terdapat error message yang menandakan bahwa username wajib diinput
      cy.get('.error-message-container')
        .should('be.visible')
        .and('contain', 'Username is required');
    });
  });
  