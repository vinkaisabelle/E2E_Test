// Scenario: Login fails with user hasn't entered password

describe('Login fails with user hasn\'t entered password', () => 
{
    it('should remain on the login page and show "Password is required" error message', () => 
    {
      // Masuk ke dalam halaman login
      cy.visit('https://www.saucedemo.com');
  
      // Ini kondisinya pengguna tidak memasukkan password, hanya memasukkan username saja
      cy.get('#user-name').type('standard_user');  
      cy.get('#password').clear();   // dibiarkan kosong saja
      cy.get('#login-button').click();
      cy.url().should('include', '/index.html');
      cy.get('.error-message-container')
        .should('be.visible')
        .and('contain', 'Password is required');
    });
  });
  