// Scenario : Successful login with valid credentials

describe('Successful login with valid credentials', () => 
{
    it('should log in and show the products page', () => 
    {
      // Digunakan untuk visit ke website Swag Labs
      cy.visit('https://www.saucedemo.com');
  
      // Saat input username dan password yang benar
      cy.get('#user-name').type('standard_user'); 
      cy.get('#password').type('secret_sauce');   
      cy.get('#login-button').click();            
  
      // Ini menuju ke inventory list produk yang ada di Swag Labs
      cy.url().should('include', '/inventory.html');
  
      // Digunakan untuk mengecek list produk yang akan ditampilkan
      cy.get('.inventory_list').should('be.visible');
    });
  });
  
  